package nine;

public class Ujji {

}
